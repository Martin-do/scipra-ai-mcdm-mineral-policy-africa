# Latest full acquisition audit

This subfolder is deliberately separate from the screened preliminary corpus in the parent folder.

The parent handoff contains the current screened reconstruction snapshot used for external corpus review. The files here record the later, broader acquisition/QC pass, including archive-discovered candidates that have not all been accepted as corpus members.

The latest recorded audit processed 1,056 candidates, of which 1,045 were acquired/extracted. These are acquisition/QC counts, **not a final corpus size**. Substantive eligibility screening, duplicate/mirror resolution, acquisition/text-quality review, final inclusion/exclusion decisions and corpus freeze are still required before annotation or modelling.
